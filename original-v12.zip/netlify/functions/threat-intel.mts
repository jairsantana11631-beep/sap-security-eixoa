import type { Context, Config } from "@netlify/functions";

function json(data:unknown,status=200){
  return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8"}});
}
function norm(v:any){return String(v||"").trim()}
function ptDate(v?:string){if(!v)return "não informado";try{return new Date(v).toLocaleDateString("pt-BR")}catch{return v}}
function pickCvss(c:any){
  const m=c?.metrics||{};
  for(const k of ["cvssMetricV40","cvssMetricV31","cvssMetricV30","cvssMetricV2"]){
    const x=m?.[k]?.[0]; if(x?.cvssData) return {score:x.cvssData.baseScore??null,severity:x.cvssData.baseSeverity||x.baseSeverity||"",version:x.cvssData.version||""};
  }
  return {score:null,severity:"",version:""};
}
async function nvd(id:string){
  const r=await fetch(`https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=${encodeURIComponent(id)}`,{headers:{"User-Agent":"SAP-Security-Eixo/1.0"}});
  if(!r.ok)return null; const d:any=await r.json(); return d?.vulnerabilities?.[0]?.cve||null;
}
async function kev(id:string){
  const r=await fetch("https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",{headers:{"User-Agent":"SAP-Security-Eixo/1.0"}});
  if(!r.ok)return null; const d:any=await r.json(); return (d?.vulnerabilities||[]).find((x:any)=>String(x?.cveID||"").toUpperCase()===id.toUpperCase())||null;
}
function priority(cv:any,k:any,hint:string){
  if(k)return "P1 — Imediata";
  const s=Number(cv.score||0), sev=String(cv.severity||hint||"").toUpperCase();
  if(s>=9||sev==="CRITICAL")return "P1 — Crítica";
  if(s>=7||sev==="HIGH")return "P2 — Alta";
  if(s>=4||sev==="MEDIUM")return "P3 — Média";
  return "P4 — Planejada";
}
export default async (req:Request, context:Context)=>{
  if(req.method==="GET") return json({configured:true,source_mode:"public",providers:["NVD","CISA KEV"]});
  if(req.method!=="POST") return json({error:"Método não suportado"},405);
  try{
    const b:any=await req.json(), mode=norm(b?.mode||"generic"), title=norm(b?.title||b?.topic||"Threat Intelligence SAP"), area=norm(b?.area||"SAP Security"), ctx=b?.context||{};
    const raw=norm(ctx?.cve||title).toUpperCase(), m=raw.match(/CVE-\d{4}-\d{4,}/i), id=m?.[0]?.toUpperCase()||"";
    if(mode==="vulnerability"){
      if(!id) return json({text:"SAP THREAT INTELLIGENCE\n\nNenhum CVE válido foi identificado. Informe um identificador no padrão CVE-AAAA-NNNN para correlação automática com NVD e CISA KEV.\n\nEnquanto isso, valide sistema, componente, versão, exposição, severidade, controles compensatórios e advisory oficial do fornecedor.",generated_at:new Date().toISOString(),source_mode:"public"});
      const [c,k]=await Promise.all([nvd(id),kev(id)]);
      if(!c) return json({text:`SAP THREAT INTELLIGENCE\nCVE: ${id}\n\nO NVD não retornou detalhes neste momento. Confirme o CVE e consulte o advisory oficial do fornecedor/SAP Security Note.\n\nFonte: https://nvd.nist.gov/vuln/detail/${encodeURIComponent(id)}`,generated_at:new Date().toISOString(),source_mode:"public"});
      const cv=pickCvss(c), desc=c?.descriptions?.find((x:any)=>x.lang==="en")?.value||norm(ctx?.description)||"Descrição não disponível.", p=priority(cv,k,norm(ctx?.severity));
      const refs=(c?.references||[]).slice(0,5).map((x:any)=>x.url).filter(Boolean);
      const text=[
        "SAP THREAT INTELLIGENCE",`CVE: ${id}`,`Prioridade: ${p}`,`CVSS: ${cv.score??"não disponível"} ${cv.severity||""} ${cv.version?`(v${cv.version})`:""}`,`Publicado: ${ptDate(c?.published)}`,`Última modificação: ${ptDate(c?.lastModified)}`,"",
        "1. Situação atual",desc,"",
        "2. Exploração conhecida",k?`SIM — consta no catálogo CISA KEV desde ${ptDate(k.dateAdded)}. ${norm(k.requiredAction)}`:"Não encontrada no catálogo CISA KEV no momento desta consulta.","",
        "3. Exposição SAP","Confirme produto, componente e versão no ambiente antes de classificar como afetado. A correlação automática não substitui a validação da SAP Security Note/advisory oficial.","",
        "4. Impacto e prioridade",`Prioridade recomendada: ${p}. Considere criticidade do sistema, exposição externa, dados processados e controles compensatórios.`,"",
        "5. Próximos passos","• Confirmar componente e versão afetados.","• Verificar SAP Security Note/advisory oficial.","• Se houver KEV, tratar como prioridade máxima.","• Aplicar correção/mitigação em teste antes da produção.","• Validar logs e sinais de exploração.","• Registrar evidências antes e depois da correção.","• Reavaliar o risco após a remediação.","",
        "6. Evidências para auditoria","• inventário e versão; • análise de aplicabilidade; • ticket de mudança; • patch/SAP Note; • testes; • logs; • aprovação e fechamento.","",
        "7. Fontes",`NVD: https://nvd.nist.gov/vuln/detail/${encodeURIComponent(id)}`,"CISA KEV: https://www.cisa.gov/known-exploited-vulnerabilities-catalog",...refs.map((u:string)=>`Referência: ${u}`)
      ].join("\n");
      return json({text,generated_at:new Date().toISOString(),source_mode:"public",priority:p,kev:Boolean(k),cvss:cv});
    }
    return json({text:`THREAT INTELLIGENCE SAP — ${title}\n\nÁrea: ${area}\n\nEste recurso funciona sem OpenAI e sem API key. Para ARA, ARM, BRM e EAM, use a documentação funcional SAP; para vulnerabilidades, informe um CVE para correlação automática com NVD e CISA KEV.\n\nPróximos passos:\n• validar configuração e versão do componente;\n• revisar riscos e acessos relacionados;\n• consultar documentação oficial SAP e notas de segurança aplicáveis;\n• registrar evidências e plano de correção.`,generated_at:new Date().toISOString(),source_mode:"public"});
  }catch(e:any){return json({error:e?.message||"Erro ao consultar Threat Intelligence público"},500)}
};
export const config:Config={path:"/threat-intel"};
