import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

function store() {
  return getStore("sap-security-eixo-media", { consistency: "strong" });
}
function json(data: unknown, status=200) {
  return new Response(JSON.stringify(data), {status, headers: {"content-type":"application/json; charset=utf-8"}});
}
function safe(s:string){ return s.replace(/[^a-zA-Z0-9._-]+/g,"_").slice(0,160); }

export default async (req: Request, context: Context) => {
  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "";
    const s = store();

    if (req.method === "GET" && action === "list") {
      const module = safe(url.searchParams.get("module") || "");
      const result = await s.list({prefix: module ? `files/${module}/` : "files/"});
      const items:any[] = [];
      for (const b of result.blobs) {
        const meta = await s.getMetadata(b.key);
        if (meta?.metadata) items.push({key:b.key, ...meta.metadata});
      }
      items.sort((a,b)=>String(b.uploadedAt||"").localeCompare(String(a.uploadedAt||"")));
      return json({items});
    }

    if (req.method === "GET" && action === "download") {
      const key = url.searchParams.get("key") || "";
      if (!key.startsWith("files/")) return json({error:"Arquivo inválido"},400);
      const found = await s.getWithMetadata(key, {type:"arrayBuffer"});
      if (!found?.data) return json({error:"Arquivo não encontrado"},404);
      const m:any = found.metadata || {};
      return new Response(found.data, {headers:{
        "content-type": m.contentType || "application/octet-stream",
        "content-disposition": `inline; filename="${safe(m.name || "arquivo")}"`,
        "cache-control":"public, max-age=300"
      }});
    }

    if (req.method === "POST") {
      if (!req.headers.get("authorization")) return json({error:"Entre na Área Administrativa para publicar."},401);
      const fd = await req.formData();
      const file = fd.get("file");
      if (!(file instanceof File)) return json({error:"Escolha um arquivo."},400);
      const module = safe(String(fd.get("module") || "geral"));
      const title = String(fd.get("title") || file.name);
      const type = safe(String(fd.get("type") || (file.type==="application/pdf"?"pdf":"material")));
      const key = `files/${module}/${Date.now()}-${safe(file.name)}`;
      const bytes = await file.arrayBuffer();
      await s.set(key, bytes, {metadata:{
        module, title, type, name:file.name, size:file.size,
        contentType:file.type || "application/octet-stream",
        uploadedAt:new Date().toISOString()
      }});
      return json({ok:true,key,title,name:file.name,type,size:file.size},201);
    }

    if (req.method === "DELETE") {
      if (!req.headers.get("authorization")) return json({error:"Entre na Área Administrativa para excluir."},401);
      const key = url.searchParams.get("key") || "";
      if (!key.startsWith("files/")) return json({error:"Arquivo inválido"},400);
      await s.delete(key);
      return json({ok:true});
    }

    return json({error:"Operação não suportada"},405);
  } catch (e:any) {
    console.error(e);
    return json({error:e?.message || "Erro interno"},500);
  }
};

export const config: Config = { path: "/media-api" };
